package handler

import (
	"encoding/json"
	"fruit-slot-api/logic"
	"net/http"
)

func PlayHandler(w http.ResponseWriter, r *http.Request) {
	spin, err := logic.GetRandomFruits()
	if err != nil {
		http.Error(w, "Failed to generate fruits", http.StatusInternalServerError)
		return
	}

	message := "Try again!"
	if logic.CheckWin(spin) {
		message = "You win!"
	}

	response := map[string]interface{}{
		"fruits":  spin,
		"message": message,
	}

	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(response)
}
