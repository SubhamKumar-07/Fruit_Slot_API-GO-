package logic

import (
	"crypto/rand"
	"math/big"
)

var fruits = []string{"Cherry", "Lemon", "Orange", "Grape", "Watermelon", "Pineapple"}

// GetRandomFruits generates 3 random fruits securely
func GetRandomFruits() ([]string, error) {
	result := make([]string, 3)
	for i := 0; i < 3; i++ {
		num, err := rand.Int(rand.Reader, big.NewInt(int64(len(fruits))))
		if err != nil {
			return nil, err
		}
		result[i] = fruits[num.Int64()]
	}
	return result, nil
}
