package logic

// CheckWin determines if at least 2 fruits are the same
func CheckWin(spin []string) bool {
	counts := make(map[string]int)
	for _, fruit := range spin {
		counts[fruit]++
		if counts[fruit] >= 2 {
			return true
		}
	}
	return false
}
