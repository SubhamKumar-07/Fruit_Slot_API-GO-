package main

import (
	"fmt"
	"log"
	"net/http"

	"fruit-slot-api/handler"
)

func main() {
	http.HandleFunc("/play", handler.PlayHandler)
	fmt.Println("Server started on http://localhost:8080")
	log.Fatal(http.ListenAndServe(":8080", nil))
}
